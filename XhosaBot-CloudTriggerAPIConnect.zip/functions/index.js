const functions = require("firebase-functions");
let Message = require("./message.js");
let apiRequestGenerator = require("./apiRequestGenerator.js");
var submitResponse = require("./submitResponse.js");
let responseGenerator = require("./responseGenerator.js");



exports.triggerNewMessageWrite = functions.firestore
    .document('{userCollectionId}/{messageId}')
    .onCreate((snap, context) => {
        const userId = getUserId(context.resource.name);
        const newMessage = snap.data();
        const messageFromBot = newMessage.messageFromBot;
        const messageSendTime = newMessage.messageSendTime;
        const messageText = newMessage.messageText;
        if (messageFromBot === false) {
            // new message object
            let userMessage = new Message(messageFromBot, messageSendTime, messageText);
            console.log("Initiating Message transfer: " + messageText + " from user: " + userId);

            var requestPromise = apiRequestGenerator.startRequest(messageText);
            requestPromise.then(function (result) {
                console.log(result);
                let outputText = responseGenerator(result);
                console.log("Data:" + outputText);
                let responseMessage = new Message(response);

                console.log("Message Returned! " + outputText);
                submitResponse(userId, responseMessage);
                console.log("Submit complete?! ");
                return true;
            }, function (err) {
                console.log(err);
            });

        } else {
            console.log("Ignore Message write from bot.");
            return false;
        }
    });

    function getUserId(resourceName) {
        let resources = resourceName.split('/');
        return resources[5];
    }
